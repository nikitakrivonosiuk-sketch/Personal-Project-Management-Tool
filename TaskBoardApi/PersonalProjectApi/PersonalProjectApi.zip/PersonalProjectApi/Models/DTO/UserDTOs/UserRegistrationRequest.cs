﻿using System.ComponentModel.DataAnnotations;

namespace PersonalProjectApi.Models.DTO.UserDTOs
{
    public class UserRegistrationRequest
    {
        [Required]
        public string Login { get; set; }
        [Required]
        public string Password { get; set; }
    }
}
