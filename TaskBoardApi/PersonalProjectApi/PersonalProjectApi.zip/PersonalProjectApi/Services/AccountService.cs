﻿using Microsoft.AspNetCore.Identity;
using PersonalProjectApi.Models.Domain;
using PersonalProjectApi.Models.DTO.UserDTOs;

namespace PersonalProjectApi.Services
{
    public class AccountService
    {
        private readonly UserManager<AppUser> _userManager;
        public AccountService(UserManager<AppUser> manager)
        {
            _userManager = manager;
        }

        public async Task<IdentityResult> CreateUserAsync(UserRegistrationRequest request)
        {
            var user = new AppUser { UserName =  request.Login };
            var result = await _userManager.CreateAsync(user, request.Password);

            return result;
        }
    }
}
